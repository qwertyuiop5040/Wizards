package wizards.constants;

public class Tags {
	public static final String USERNAME="-s";
	public static final String REQUEST_WORLD="-r";
	public static final String WORLD_INFORMATION="-w";
	public static final String CHANGE_AVATAR_LOCATION="-l";
}
