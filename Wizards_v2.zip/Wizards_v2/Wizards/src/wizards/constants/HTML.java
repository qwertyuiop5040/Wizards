package wizards.constants;

public interface HTML {
	public static final String CENTER_TEXT="<div style=\"text-align:center;\">";
	public static final String HTML="<html>";
	public static final String END_HTML="</html>";
	public static final String NEW_LINE="<br>";
}
