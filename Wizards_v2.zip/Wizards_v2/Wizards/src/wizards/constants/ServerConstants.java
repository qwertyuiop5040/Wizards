package wizards.constants;

public interface ServerConstants {
	public static final int PORT=7347;
}
